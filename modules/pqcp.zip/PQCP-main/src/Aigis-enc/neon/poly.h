/*
 * Copyright (c) 2026 openHiTLS. All Rights Reserved.
 *
 * PQCP is licensed under the Mulan PSL v2.
 * You can use this software according to the terms and conditions of the Mulan PSL v2.
 * You may obtain a copy of Mulan PSL v2 at:
 *
 *     http://license.coscl.org.cn/MulanPSL2
 *
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT,
 * MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
 * See the Mulan PSL v2 for more details.
 */

#ifndef POLY_H
#define POLY_H

#include <stdint.h>
#include "params.h"

/* 
 * Elements of R_q = Z_q[X]/(X^n + 1). Represents polynomial
 * coeffs[0] + X*coeffs[1] + X^2*xoeffs[2] + ... + X^{n-1}*coeffs[n-1] 
 */

typedef struct{
	ALIGN(32) int16_t coeffs[PARAM_N];
} poly;

void poly_caddq(poly *r);
void poly_caddq2(poly *r);
void poly_reduce(poly *r);
void poly_compress(uint8_t *r, const poly *a); //each coefficient of a is compressed into cbits  
void poly_decompress(poly *r, const uint8_t *a);
void poly_tobytes(uint8_t *r, const poly *a);
void poly_frombytes(poly *r, const uint8_t *a);
void poly_frommsg(poly *r, const uint8_t msg[SEED_BYTES]);
void poly_tomsg(uint8_t msg[SEED_BYTES], const poly *r);
void poly_ss_getnoise(poly *r,const uint8_t *seed, uint8_t nonce);
void poly_ee_getnoise(poly *r, const uint8_t *seed, uint8_t nonce);
void poly_add(poly *r, const poly *a, const poly *b);
void poly_sub(poly *r, const poly *a, const poly *b);
void poly_getmontgomery(poly* r);
void poly_mont_mul(poly* r, const poly* a, const poly* b);
void poly_ntt(poly *r);
void poly_invntt(poly *r);
void poly_compress10(uint8_t *r, const poly *a);
void poly_decompress10(poly *r, const uint8_t *a);
#endif
