make clean
make
./app
