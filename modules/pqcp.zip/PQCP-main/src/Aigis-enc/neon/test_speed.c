/*
 * Copyright (c) 2026 openHiTLS. All Rights Reserved.
 *
 * PQCP is licensed under the Mulan PSL v2.
 * You can use this software according to the terms and conditions of the Mulan PSL v2.
 * You may obtain a copy of Mulan PSL v2 at:
 *
 *     http://license.coscl.org.cn/MulanPSL2
 *
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT,
 * MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
 * See the Mulan PSL v2 for more details.
 */

#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include "api.h"
#include "randombytes.h"
#include "cpucycles.h"
#include "genmatrix.h"
#include "owcpa.h"
#include "poly.h"
#include "speed_print.h"

#define NTESTS 100000

uint64_t t[NTESTS];

int main()
{
  unsigned int i;
  unsigned char pk[CRYPTO_PUBLICKEYBYTES + 32] = {0};
  unsigned char sk[CRYPTO_SECRETKEYBYTES + 32] = {0};
  unsigned char ct[CRYPTO_CIPHERTEXTBYTES +32] = {0};
  __attribute__((aligned(32)))
  unsigned char key[CRYPTO_BYTES] = {0};
unsigned char       entropy_input[48];
  poly a,u;
  poly e, pkpv, skpv;

mkem_keygen(pk, sk);
mkem_enc(pk,key,ct);
mkem_dec(sk, ct, key);

for (int i=0; i<48; i++)
        entropy_input[i] = i;

  //  randombytes_init(entropy_input, NULL, 256);

  
  printf("*****************************\n");
  printf("PK Sizes:%d\n",CRYPTO_PUBLICKEYBYTES);
  printf("SK Sizes:%d\n",CRYPTO_SECRETKEYBYTES);
  printf("CT Sizes:%d\n",CRYPTO_CIPHERTEXTBYTES);
  printf("TOTAL COST:%d\n",CRYPTO_CIPHERTEXTBYTES + CRYPTO_PUBLICKEYBYTES);
  printf("*****************************\n");

  // for(i=0;i<NTESTS;i++) {
  //   t[i] = cpucycles();
  //   gen_a(&a, ct);
  // }
  // print_results("gen_a: ", t, NTESTS);
  //
  // for(i=0;i<NTESTS;i++) {
  //   t[i] = cpucycles();
  //   poly_ntt(&skpv);
  // }
  // print_results("poly_ntt: ", t, NTESTS);
  //
  // for(i=0;i<NTESTS;i++) {
  //   t[i] = cpucycles();
  //   poly_invntt(&u);
  // }
  // print_results("poly_invntt: ", t, NTESTS);
  //
  // for(i=0;i<NTESTS;i++) {
  //   t[i] = cpucycles();
  //     poly_compress10(ct,&a);;
  // }
  // print_results("poly_compress10: ", t, NTESTS);
  //
  // for(i=0;i<NTESTS;i++) {
  //   t[i] = cpucycles();
  //   poly_mont_mul(&pkpv, &skpv, &a);;
  // }
  // print_results("poly_mont_mul: ", t, NTESTS);
  //
  // for(i=0;i<NTESTS;i++) {
  //   t[i] = cpucycles();
  //   owcpa_keypair(pk, sk);
  // }
  // print_results("owcpa_keypair: ", t, NTESTS);
  //
  // for(i=0;i<NTESTS;i++) {
  //   t[i] = cpucycles();
  //   owcpa_enc(pk,key,ct,sk);
  // }
  // print_results("owcpa_enc: ", t, NTESTS);
  //
  // for(i=0;i<NTESTS;i++) {
  //   t[i] = cpucycles();
  //   owcpa_dec(sk, ct, key);
  // }
  // print_results("owcpa_dec: ", t, NTESTS);

  for(i=0;i<NTESTS;i++) {
    t[i] = cpucycles();
    mkem_keygen(pk, sk);
  }
  print_results("Aigis-enc_keypair: ", t, NTESTS);

  for(i=0;i<NTESTS;i++) {
    t[i] = cpucycles();
    mkem_enc(pk,key,ct);
  }
  print_results("Aigis-enc_encaps: ", t, NTESTS);

  for(i=0;i<NTESTS;i++) {
    t[i] = cpucycles();
    if(mkem_dec(sk, ct, key))
	printf("decryption failure!\n");
  }
  print_results("Aigis-enc_decaps: ", t, NTESTS);

  return 0;
}
